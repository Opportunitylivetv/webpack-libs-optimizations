Samples for PayPal-node-SDK
===========================
These samples relate one-to-one with API functionalities supported via node sdk

- Before executing run the following

```sh
npm install ../
```

- To run samples 

```sh
node <sample file name>
ex: node payment/get.js
```
