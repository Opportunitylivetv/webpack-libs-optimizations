"use strict";

var paypal = require('../');
require('../samples/configure');
