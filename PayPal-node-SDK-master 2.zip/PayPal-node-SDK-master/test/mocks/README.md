Mock files generated using https://github.com/pgte/nock#recording.

Unit tests will run in mock mode, disable by setting environment varible NOCK_OFF=true
